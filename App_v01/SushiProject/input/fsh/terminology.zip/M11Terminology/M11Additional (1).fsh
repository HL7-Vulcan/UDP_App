// M11Additional.fsh
// Value sets used in the UDP app that do not yet have their own FSH file.

//-----------------------------------------------------
// Code List C217048
// ICH OID (to be confirmed)
ValueSet: M11TimeUnitVS
Id: C217048
Title: "ICH M11 Time Unit Value Set Terminology"
Description: """Terminology associated with the Time Unit value set codelist of the ICH M11 protocol template.
This is ICH M11 Value Set C217048 drawn from the NCI Thesaurus and represented here in FHIR format.
Used to express the unit for age limits, intervention duration and participation duration."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $NCIT#C25529 "Hours"
* $NCIT#C25301 "Days"
* $NCIT#C29844 "Weeks"
* $NCIT#C29846 "Months"
* $NCIT#C29848 "Years"

//-----------------------------------------------------
// Code List C217285
// ICH OID (to be confirmed)
ValueSet: M11InterventionRoleVS
Id: m11-intervention-role-vs
Title: "ICH M11 Intervention Role Value Set Terminology"
Description: """Terminology associated with the Intervention Role value set codelist of the ICH M11 protocol template.
This is ICH M11 Value Set C217285 drawn from the NCI Thesaurus and represented here in FHIR format."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $NCIT#C41161  "Experimental Intervention"
* $NCIT#C753    "Placebo"
* $NCIT#C165835 "Rescue Medicine"
* $NCIT#C165822 "Background Treatment"
* $NCIT#C158128 "Challenge Agent"
* $NCIT#C18020  "Diagnostic"
* $NCIT#C207614 "Additional Required Treatment"

//-----------------------------------------------------
// Code List C217286
// ICH OID (to be confirmed)
ValueSet: M11MpNimpVS
Id: m11-mp-nimp-vs
Title: "ICH M11 MP/NIMP Classification Value Set Terminology"
Description: """Terminology associated with the MP/NIMP Classification value set codelist of the ICH M11 protocol template.
This is ICH M11 Value Set C217286 drawn from the NCI Thesaurus and represented here in FHIR format.
Classifies each trial intervention as a Medicinal Product (MP) or Non-Investigational Medicinal Product (NIMP)."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $NCIT#C202579 "MP"
* $NCIT#C156473 "NIMP"

//-----------------------------------------------------
// Code List C217052
// ICH OID (to be confirmed)
ValueSet: M11SourcingVS
Id: m11-sourcing-vs
Title: "ICH M11 Sourcing Value Set Terminology"
Description: """Terminology associated with the Sourcing value set codelist of the ICH M11 protocol template.
This is ICH M11 Value Set C217052 drawn from the NCI Thesaurus and represented here in FHIR format."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $NCIT#C215659 "Centrally Sourced"
* $NCIT#C215660 "Locally Sourced"

//-----------------------------------------------------
// Code List C217287
// ICH OID (to be confirmed)
ValueSet: M11SafetyEventTypeVS
Id: m11-safety-event-type-vs
Title: "ICH M11 Safety Event Type Value Set Terminology"
Description: """Terminology associated with the Safety Event Type value set codelist of the ICH M11 protocol template.
This is ICH M11 Value Set C217287 drawn from the NCI Thesaurus and represented here in FHIR format."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $NCIT#C41331  "Adverse Event"
* $NCIT#C41335  "Serious Adverse Event"
* $NCIT#C218508 "Trial Intervention Complaint"
* $NCIT#C222331 "Drug/Device Combination Product Complaint"
* $NCIT#C25742  "Pregnancy Event"
* $NCIT#C218510 "Lactation Event"
* $NCIT#C218511 "Post-Partum Event"
* $NCIT#C218512 "Reportable Adverse Event of Special Interest"
* $NCIT#C218513 "Not Reportable Adverse Event of Special Interest"
* $NCIT#C17649  "Other"

//-----------------------------------------------------
// Country and Region: ISO-coded, not NCI — placeholder lists
// Extend by adding ISO 3166 / ISO 3166-2 entries as required.

ValueSet: M11CountryVS
Id: m11-country-vs
Title: "ICH M11 Country Value Set"
Description: """ISO 3166 country codes for sponsor country of record.
This value set uses ISO 3166 coding rather than NCI codes. Extend as needed."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $iso3166#AU "Australia"
* $iso3166#FR "France"
* $iso3166#DE "Germany"
* $iso3166#IN "India"
* $iso3166#GB "UK"

ValueSet: M11RegionVS
Id: m11-region-vs
Title: "ICH M11 Region Value Set"
Description: """ISO 3166-2 region/subdivision codes for sponsor region of record.
This value set uses ISO 3166-2 coding rather than NCI codes. Extend as needed."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $iso3166-2#AU-NSW "New South Wales"
* $iso3166-2#DE-BY  "Bavaria"
* $iso3166-2#FR-NOR "Normandy"
* $iso3166-2#IN-UP  "Uttar Pradesh"
* $iso3166-2#GB-WLS "Wales"

//-----------------------------------------------------
// Dose Form and Route: EDQM/IDMP-coded, not NCI — placeholder lists
// Replace $IDMP_DUMMY codes with real EDQM codes when available.

ValueSet: M11DoseFormVS
Id: m11-dose-form-vs
Title: "ICH M11 Pharmaceutical Dose Form Value Set"
Description: """Pharmaceutical dose form of the investigational product.
This value set uses EDQM/IDMP coding rather than NCI codes. The entries below are placeholders — replace with real EDQM standard term codes."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $IDMP_DUMMY#f1 "tablet"
* $IDMP_DUMMY#f2 "capsule"
* $IDMP_DUMMY#f3 "solution for injection"

ValueSet: M11RouteVS
Id: m11-route-vs
Title: "ICH M11 Route of Administration Value Set"
Description: """Route of administration of the investigational product.
This value set uses EDQM/IDMP coding rather than NCI codes. The entries below are placeholders — replace with real EDQM standard term codes."""
* insert rs-copyright-terminology
* ^extension[$ext-fmm].valueInteger = 0
* ^experimental = false
* ^status = #active
* ^publisher = "ICH M11"

* $IDMP_DUMMY#R1 "oral"
* $IDMP_DUMMY#R2 "subcutaneous injection"
* $IDMP_DUMMY#R3 "topical"
