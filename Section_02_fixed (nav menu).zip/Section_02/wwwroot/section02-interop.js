// ── File download ─────────────────────────────────────────────────
window.udpDownload = function (filename, content, mimeType) {
    const encoded = 'data:' + mimeType + ';charset=utf-8,' + encodeURIComponent(content);
    const a = document.createElement('a');
    a.href = encoded;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};

// ── File picker (load JSON) ────────────────────────────────────────
let _dotNetRef = null;

window.udpSetDotNetRef = function (ref) {
    _dotNetRef = ref;
};

window.udpOpenFilePicker = function () {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.style.display = 'none';
    document.body.appendChild(input);
    input.addEventListener('change', function () {
        const file = input.files[0];
        if (!file) { document.body.removeChild(input); return; }
        const reader = new FileReader();
        reader.onload = function (e) {
            document.body.removeChild(input);
            if (_dotNetRef) {
                _dotNetRef.invokeMethodAsync('ReceiveFileContent', e.target.result);
            }
        };
        reader.readAsText(file);
    });
    input.click();
};
