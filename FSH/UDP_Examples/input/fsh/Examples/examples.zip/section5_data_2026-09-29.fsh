Instance: Narrative-Composition-M11Section05
InstanceOf: m11-research-study-narratives
Title: "Example Narrative Single Composition with a Section for Each M11 Section"
Usage: #example
Description: """Example Narrative Single Composition with a contained section for e part of M11 Section 02.
"""

* status = #final
* type = $NCIT#C207508 // Narrative
* date = "2025-06-30T12:46:00Z"
* author = Reference(Narrative-Organization) // Reference to Organization: Marketing 
* title = "Example Narrative with Section per Section - (this is the Composition Title}"

/* 
* $NCIT#C218547  "ICH M11 Protocol Section 5 TRIAL POPULATION"
* $NCIT#C218548  "ICH M11 Protocol Section 5.1 Description of Trial Population and Rationale"
* $NCIT#C218549  "ICH M11 Protocol Section 5.2 Inclusion Criteria"
* $NCIT#C218550  "ICH M11 Protocol Section 5.3 Exclusion Criteria"
* $NCIT#C218551  "ICH M11 Protocol Section 5.4 Contraception"
* $NCIT#C218552  "ICH M11 Protocol Section 5.4.1 Definitions Related to Childbearing Potential"
* $NCIT#C218553  "ICH M11 Protocol Section 5.4.2 Contraception Requirements"
* $NCIT#C218554  "ICH M11 Protocol Section 5.5 Lifestyle Restrictions"
* $NCIT#C218555  "ICH M11 Protocol Section 5.5.1 Meals and Dietary Restrictions"
* $NCIT#C218556  "ICH M11 Protocol Section 5.5.2 Caffeine, Alcohol, Tobacco, and Other Restrictions"
* $NCIT#C218557  "ICH M11 Protocol Section 5.5.3 Physical Activity Restrictions"
* $NCIT#C218558  "ICH M11 Protocol Section 5.5.4 Other Activity Restrictions"
* $NCIT#C218559  "ICH M11 Protocol Section 5.6 Screen Failure and Rescreening"
* $UDP_Term#009  "ICH M11 Protocol Section 5.6.1 Screen Failure"
* $UDP_Term#010  "ICH M11 Protocol Section 5.6.2 Rescreening"
*/


* section[+]
  * title = "Section 5.1"
  * code = $NCIT#C218548  "ICH M11 Protocol Section 5.1 Description of Trial Population and Rationale"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
        The trial will enrol adult participants aged 18 to 75 years with a confirmed diagnosis of moderate-to-severe plaque psoriasis, defined as a Psoriasis Area and Severity Index (PASI) score of 12 or greater and a body surface area (BSA) involvement of 10% or greater at screening.
        </div>
      """


// Patients aged 30-60 years with a body-mass index of 35 kg/m(2) or more and a history of type 2 diabetes lasting at least 5 years
* section[+]
  * title = "Section 5.2"
  * code = $NCIT#C218549  "ICH M11 Protocol Section 5.2 Inclusion Criteria"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants must meet all of the following inclusion criteria to be eligible for enrolment.
        </div>
      """
  * entry[+] = Reference(eligibility-group-inclusion-age-weight)
  * entry[+] = Reference(eligibility-group-inclusion-diagnosis-consent)
  * entry[+] = Reference(exclusion-group-exclusion-prior-biologics)
  * entry[+] = Reference(exclusion-group-exclusion-pregnancy)
//  * extension[order].valueInteger = {{n}}

// * section[+]
//   * title = "Section 5.2"
//   * code = $NCIT#C218549  "ICH M11 Protocol Section 5.2 Inclusion Criteria"
//   * text.status = #additional
//   * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
// Participants must meet all of the following inclusion criteria to be eligible for enrolment.
//         </div>
//       """
//   * entry[+] = Reference(eligibility-group-diabetes) 
//   * extension[order].valueInteger = 2


* section[+]
  * title = "Section 5.3"
  * code = $NCIT#C218550  "ICH M11 Protocol Section 5.3 Exclusion Criteria"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants meeting any of the following exclusion criteria are not eligible for enrolment.
    </div>
    """

* section[+]
  * title = "Section 5.4.1"
  * code = $NCIT#C218552  "ICH M11 Protocol Section 5.4.1 Definitions Related to Childbearing Potential"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Women of childbearing potential (WOCBP) are defined as women who are biologically capable of becoming pregnant. Women who are postmenopausal (at least 12 consecutive months of spontaneous amenorrhoea) or permanently sterile are not considered WOCBP.
    </div>
    """

* section[+]
  * title = "Section 5.4.2"
  * code = $NCIT#C218553  "ICH M11 Protocol Section 5.4.2 Contraception Requirements"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
WOCBP must agree to use a highly effective method of contraception from the time of screening until at least 12 weeks after the last dose of investigational product.
    </div>
    """

* section[+]
  * title = "Section 5.5"
  * code = $NCIT#C218554  "ICH M11 Protocol Section 5.5 Lifestyle Restrictions"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants must comply with the following lifestyle restrictions throughout their participation in the trial.
    </div>
    """

* section[+]
  * title = "Section 5.5.1"
  * code = $NCIT#C218555  "ICH M11 Protocol Section 5.5.1 Meals and Dietary Restrictions"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants must avoid grapefruit, grapefruit juice, and Seville oranges from 7 days prior to the first dose until the end of the treatment period.
    </div>
    """

* section[+]
  * title = "Section 5.5.2"
  * code = $NCIT#C218559  "ICH M11 Protocol Section 5.5.2 Caffeine, Alcohol, Tobacco, and Other Restrictions"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants must abstain from alcohol consumption within 24 hours prior to and 24 hours following each study visit.
    </div>
    """

* section[+]
  * title = "Section 5.5.3"
  * code = $NCIT#C218557  "ICH M11 Protocol Section 5.5.3 Physical Activity Restrictions"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants should avoid strenuous physical activity within 48 hours prior to scheduled blood sampling visits.
    </div>
    """

* section[+]
  * title = "Section 5.5.4"
  * code = $NCIT#C218558  "ICH M11 Protocol Section 5.5.4 Other Activity Restrictions"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
No other activity restrictions apply.
    </div>
    """



* section[+]
  * title = "Section 5.6.1"
  * code = $UDP_Term#009  "ICH M11 Protocol Section 5.6.1 Screen Failure"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants who fail to meet eligibility criteria at screening will be considered screen failures and their data collected to understand the characteristics of the screened population.
    </div>
    """

* section[+]
  * title = "Section 5.6.2"
  * code = $UDP_Term#010  "ICH M11 Protocol Section 5.6.2 Rescreening"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Rescreening may be permitted once, at the discretion of the investigator, if the screen failure was due to a transient condition that has resolved.
    </div>
    """
//--------------------------------------------------------------------------------------
//
Instance: eligibility-group-inclusion-age-weight
InstanceOf: Group
Usage: #example
Description: "Simple Eligibility criteria - Age 30-60 years + BMI>=35"
* id = "eligibility-group-inclusion-age-weight" // This is specified ONLY to allow documentatation of examples - it is not normally specified

// * identifier.type = $v2-0203#FILL "Filler Identifier"
// * identifier.system = $ID-EligibilityCriteria
// * identifier.value = "172461"

* name = "inclusion-age-weight"
* title = "Age and Weight Inclusion Criteria"
* status = #active

* description = "Participants must be aged 18 to 75 years and weigh at least 40 kg."
* type = #person //#person
* membership = #definitional //#definitional
* combinationMethod = #all-of //#all-of

* characteristic[+].code = $SCT#397669002 "Age" //$SCT#397669002 "Age"
* characteristic[=].valueRange.low = 18 'a' "years" //30 'a' "years"
* characteristic[=].valueRange.high = 75 'a' "years" //60 'a' "years"
* characteristic[=].exclude = false //false
* characteristic[=].description = "aged 18 to 75 years" //"aged 30-60 years"


* characteristic[+].code = $SCT#27113001 "Body weight" //$SCT#397669002 "Weight"
* characteristic[=].valueQuantity = 40 'kg' "kilograms" //70 kg
* characteristic[=].exclude = false //false
* characteristic[=].description = "body weight at least 40 kg" //"Male"


//--------------------------------------------------------------------------------------
//
Instance: eligibility-group-inclusion-diagnosis-consent
InstanceOf: Group
Usage: #example
Description: "Simple Eligibility criteria - Age 30-60 years + BMI>=35"
* id = "eligibility-group-inclusion-diagnosis-consent" // This is specified ONLY to allow documentatation of examples - it is not normally specified

// * identifier.type = $v2-0203#FILL "Filler Identifier"
// * identifier.system = $ID-EligibilityCriteria
// * identifier.value = "172461"

* name = "inclusion-diagnosis-consent"
* title = "Diagnosis and Consent Inclusion Criteria"
* status = #active

* description = "Participants must have a confirmed diagnosis of moderate-to-severe plaque psoriasis and have provided written informed consent."
* type = #person //#person
* membership = #definitional //#definitional
* combinationMethod = #all-of //#all-of

* characteristic[+].code = $SCT#9014002 "Psoriasis" //$SCT#397669002 "Gender"
* characteristic[=].valueCodeableConcept = #ModerateSeverePlaquePsoriasis //male
* characteristic[=].exclude = false //false
* characteristic[=].description = "confirmed moderate-to-severe plaque psoriasis" //"Male"


* characteristic[+].code = $SCT#182777000 "Informed consent" //$SCT#397669002 "Consenting"
* characteristic[=].valueBoolean = true //true
* characteristic[=].exclude = false //false
* characteristic[=].description = "written informed consent obtained" //"Male"


//--------------------------------------------------------------------------------------
//
Instance: exclusion-group-exclusion-prior-biologics
InstanceOf: Group
Usage: #example
Description: "Simple Eligibility criteria - Age 30-60 years + BMI>=35"
* id = "exclusion-group-exclusion-prior-biologics" // This is specified ONLY to allow documentatation of examples - it is not normally specified

// * identifier.type = $v2-0203#FILL "Filler Identifier"
// * identifier.system = $ID-EligibilityCriteria
// * identifier.value = "172461"

* name = "exclusion-prior-biologics"
* title = "Prior Biologic Therapy Exclusion"
* status = #active

* description = "Participants who have received any biologic agent targeting IL-17, IL-23, or TNF-alpha within 24 weeks prior to randomisation are not eligible."
* type = #person //#person
* membership = #definitional //#definitional
* combinationMethod = #any-of //#all-of

* characteristic[+].code = $SCT#416897000 "IL-17 inhibitor" //$SCT#397669002 "Gender"
* characteristic[=].valueCodeableConcept = #BiologicTherapy //male
* characteristic[=].exclude = true //false
* characteristic[=].description = "prior IL-17 inhibitor within 24 weeks" //"Male"


* characteristic[+].code = $SCT#787021000 "Washout period" //$SCT#397669002 "Age"
* characteristic[=].valueRange.low = 0 'wk' "weeks" //30 'a' "years"
* characteristic[=].valueRange.high = 24 'wk' "weeks" //60 'a' "years"
* characteristic[=].exclude = true //false
* characteristic[=].description = "within 24-week washout period" //"aged 30-60 years"


//--------------------------------------------------------------------------------------
//
Instance: exclusion-group-exclusion-pregnancy
InstanceOf: Group
Usage: #example
Description: "Simple Eligibility criteria - Age 30-60 years + BMI>=35"
* id = "exclusion-group-exclusion-pregnancy" // This is specified ONLY to allow documentatation of examples - it is not normally specified

// * identifier.type = $v2-0203#FILL "Filler Identifier"
// * identifier.system = $ID-EligibilityCriteria
// * identifier.value = "172461"

* name = "exclusion-pregnancy"
* title = "Pregnancy and Infection Exclusion"
* status = #active

* description = "Participants who are pregnant or have an active systemic infection are not eligible."
* type = #person //#person
* membership = #definitional //#definitional
* combinationMethod = #any-of //#all-of

* characteristic[+].code = $SCT#77386006 "Pregnant" //$SCT#397669002 "Consenting"
* characteristic[=].valueBoolean = true //true
* characteristic[=].exclude = true //false
* characteristic[=].description = "currently pregnant" //"Male"


* characteristic[+].code = $SCT#40733004 "Infectious disease" //$SCT#397669002 "Weight"
* characteristic[=].valueQuantity = 1 '{episode}' "episode" //70 kg
* characteristic[=].exclude = true //false
* characteristic[=].description = "active systemic infection at screening" //"Male"

