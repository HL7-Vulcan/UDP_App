Instance: Narrative-Composition-M11Section06
InstanceOf: m11-research-study-narratives
Title: "Example Narrative Single Composition with a Section for Each M11 Section"
Usage: #example
Description: """Example Narrative Single Composition with a contained section for e part of M11 Section 06.
"""

* status = #final
* type = $NCIT#C207508 // Narrative
* date = "2025-06-30T12:46:00Z"
* author = Reference(Narrative-Organization) // Reference to Organization: Marketing 
* title = "Example Narrative with Section per Section - (this is the Composition Title}"

/* 
* $NCIT#C218560  "ICH M11 Protocol Section 6 TRIAL INTERVENTION AND CONCOMITANT THERAPY"
* $NCIT#C218561  "ICH M11 Protocol Section 6.1 Description of Investigational Trial Intervention"
* $NCIT#C218562  "ICH M11 Protocol Section 6.2 Rationale for Investigational Trial Intervention Dose and Regimen"
* $NCIT#C218563  "ICH M11 Protocol Section 6.3 Investigational Trial Intervention Administration"
* $NCIT#C218564  "ICH M11 Protocol Section 6.4 Investigational Trial Intervention Dose Modification"
* $NCIT#C218565  "ICH M11 Protocol Section 6.5 Management of Investigational Trial Intervention Overdose"
* $NCIT#C218566  "ICH M11 Protocol Section 6.6 Preparation, Storage, Handling and Accountability of Investigational Trial Intervention"
* $NCIT#C218567  "ICH M11 Protocol Section 6.6.1 Preparation of Investigational Trial Intervention"
* $NCIT#C218568  "ICH M11 Protocol Section 6.6.2 Storage and Handling of Investigational Trial Intervention"
* $NCIT#C218569  "ICH M11 Protocol Section 6.6.3 Accountability of Investigational Trial Intervention"
* $NCIT#C218570  "ICH M11 Protocol Section 6.7 Investigational Trial Intervention Assignment, Randomisation and Blinding"
* $NCIT#C218571  "ICH M11 Protocol Section 6.7.1 Participant Assignment to Investigational Trial Intervention"
* $NCIT#C218572  "ICH M11 Protocol Section 6.7.2 Randomisation"
* $NCIT#C218573  "ICH M11 Protocol Section 6.7.3 Measures to Maintain Blinding"
* $NCIT#C218574  "ICH M11 Protocol Section 6.7.4 Emergency Unblinding at the Site"
* $NCIT#C218575  "ICH M11 Protocol Section 6.8 Investigational Trial Intervention Adherence"
* $NCIT#C218576  "ICH M11 Protocol Section 6.9 Description of Noninvestigational Trial Intervention"
* $NCIT#C218577  "ICH M11 Protocol Section 6.9.1 Background Trial Intervention"
* $NCIT#C218578  "ICH M11 Protocol Section 6.9.2 Rescue Therapy"
* $NCIT#C218579  "ICH M11 Protocol Section 6.9.3 Other Noninvestigational Trial Intervention"
* $NCIT#C218580  "ICH M11 Protocol Section 6.10 Concomitant Therapy"
* $NCIT#C218581  "ICH M11 Protocol Section 6.10.1 Prohibited Concomitant Therapy"
* $NCIT#C218582  "ICH M11 Protocol Section 6.10.2 Permitted Concomitant Therapy"
*/

      
* section[+]
  * title = "Section 6"
  * code = $NCIT#C218560  "ICH M11 Protocol Section 6 TRIAL INTERVENTION AND CONCOMITANT THERAPY"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
This section describes the investigational and noninvestigational trial interventions, including the rationale for dose selection, administration procedures, and concomitant therapy restrictions.
        </div>
      """
  * entry[+] = Reference(InterventionTable-Row1)
  * entry[+] = Reference(InterventionTable-Row2)
  * entry[+] = Reference(InterventionTable-Row3) 
      
* section[+]
  * title = "Section 6.1"
  * code = $NCIT#C218561  "ICH M11 Protocol Section 6.1 Description of Investigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Exoticillin 500mg film-coated tablets. Nonproprietary name: exoticillin. Pharmaceutical dose form: film-coated tablet. Dosage strength: 500mg.
        </div>
      """
      
* section[+]
  * title = "Section 6.2"
  * code = $NCIT#C218562  "ICH M11 Protocol Section 6.2 Rationale for Investigational Trial Intervention Dose and Regimen"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
The dose of 500mg twice daily was selected based on Phase II data demonstrating optimal efficacy with an acceptable safety profile at this dose level.
        </div>
      """
      
* section[+]
  * title = "Section 6.3"
  * code = $NCIT#C218563  "ICH M11 Protocol Section 6.3 Investigational Trial Intervention Administration"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Exoticillin 500mg tablets will be administered orally twice daily with or without food for the duration of the treatment period.
        </div>
      """
      
* section[+]
  * title = "Section 6.4"
  * code = $NCIT#C218564  "ICH M11 Protocol Section 6.4 Investigational Trial Intervention Dose Modification"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Dose reductions to 250mg twice daily are permitted for participants experiencing Grade 2 or higher adverse events attributable to the investigational product.
        </div>
      """
      
* section[+]
  * title = "Section 6.5"
  * code = $NCIT#C218565  "ICH M11 Protocol Section 6.5 Management of Investigational Trial Intervention Overdose"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
In the event of overdose, symptomatic and supportive treatment should be provided. There is no specific antidote for exoticillin.
        </div>
      """
      
* section[+]
  * title = "Section 6.6.1"
  * code = $NCIT#C218567  "ICH M11 Protocol Section 6.6.1 Preparation of Investigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Investigational product will be supplied as blister packs by the sponsor. No preparation is required at site.
        </div>
      """
      
* section[+]
  * title = "Section 6.6.2"
  * code = $NCIT#C218568  "ICH M11 Protocol Section 6.6.2 Storage and Handling of Investigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Investigational product must be stored at room temperature (15-25°C), protected from light and moisture.
        </div>
      """
      
* section[+]
  * title = "Section 6.6.3"
  * code = $NCIT#C218569  "ICH M11 Protocol Section 6.6.3 Accountability of Investigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Site staff must maintain accurate records of all investigational product received, dispensed, and returned or destroyed.
        </div>
      """
      
* section[+]
  * title = "Section 6.7.1"
  * code = $NCIT#C218571  "ICH M11 Protocol Section 6.7.1 Participant Assignment to Investigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Participants will be assigned to treatment using an Interactive Web Response System (IWRS).
        </div>
      """
      
* section[+]
  * title = "Section 6.7.2"
  * code = $NCIT#C218572  "ICH M11 Protocol Section 6.7.2 Randomisation"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Randomisation will be performed centrally using a 1:1 ratio via the IWRS. Randomisation will be stratified by disease severity and geographic region.
        </div>
      """
      
* section[+]
  * title = "Section 6.7.3"
  * code = $NCIT#C218573  "ICH M11 Protocol Section 6.7.3 Measures to Maintain Blinding"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
This is a double-blind trial. The investigational product and placebo are identical in appearance. The IWRS will maintain the blind.
        </div>
      """
      
* section[+]
  * title = "Section 6.7.4"
  * code = $NCIT#C218574  "ICH M11 Protocol Section 6.7.4 Emergency Unblinding at the Site"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Emergency unblinding may be performed by the investigator in the event of a medical emergency. The sponsor must be notified within 24 hours.
        </div>
      """
      
* section[+]
  * title = "Section 6.8"
  * code = $NCIT#C218575  "ICH M11 Protocol Section 6.8 Investigational Trial Intervention Adherence"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Adherence will be assessed by tablet count at each visit. Participants with less than 80% adherence will be counselled by site staff.
        </div>
      """
      
* section[+]
  * title = "Section 6.9"
  * code = $NCIT#C218576  "ICH M11 Protocol Section 6.9 Description of Noninvestigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
No noninvestigational trial interventions are planned for this trial.
        </div>
      """
      
* section[+]
  * title = "Section 6.9.1"
  * code = $NCIT#C218577  "ICH M11 Protocol Section 6.9.1 Background Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Background therapy consists of standard-of-care treatment administered to all participants throughout the trial in addition to the investigational product.
        </div>
      """
      
* section[+]
  * title = "Section 6.9.2"
  * code = $NCIT#C218578  "ICH M11 Protocol Section 6.9.2 Rescue Therapy"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Rescue therapy with short-acting bronchodilators is permitted for participants experiencing acute symptom exacerbation. Use of rescue therapy will be recorded in the eCRF.
        </div>
      """
      
* section[+]
  * title = "Section 6.9.3"
  * code = $NCIT#C218579  "ICH M11 Protocol Section 6.9.3 Other Noninvestigational Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
No other noninvestigational trial interventions are planned. Any additional medications required for participant safety will be recorded as concomitant medications.
        </div>
      """
      
* section[+]
  * title = "Section 6.10"
  * code = $NCIT#C218580  "ICH M11 Protocol Section 6.10 Concomitant Therapy"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
Concomitant medications taken within 30 days prior to screening and during the trial must be recorded in the electronic case report form.
        </div>
      """
      
* section[+]
  * title = "Section 6.10.1"
  * code = $NCIT#C218581  "ICH M11 Protocol Section 6.10.1 Prohibited Concomitant Therapy"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
The following medications are prohibited during the trial: strong CYP3A4 inhibitors, strong CYP3A4 inducers, and other investigational products.
        </div>
      """
      
* section[+]
  * title = "Section 6.10.2"
  * code = $NCIT#C218582  "ICH M11 Protocol Section 6.10.2 Permitted Concomitant Therapy"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
All other concomitant medications are permitted provided they are stable for at least 30 days prior to randomisation.
        </div>
      """
//--------------------------------------------------------------------------------------
//
Instance: InterventionTable-Row1
InstanceOf: m11-intervention-table
Usage: #example

Description: "Table defining the trial interventions"
* id = "InterventionTable-Row1" // This is specified ONLY to allow documentatation of examples - it is not normally specified

* status = #draft


* title = "Active Treatment Arm" // armName
* extension[intervention].extension[armType].valueCodeableConcept = $NCIT#C174266 "Experimental Arm" // armType
* productCodeableConcept = $SpID#EX2015/03  "Exoticillin" // Sponsor Investigational Product Code (and name)
* extension[intervention].extension[interventionType].valueCodeableConcept = $NCIT#C1909 "Drug"
//* productReference(intervention-medication)
* extension[intervention].extension[dosageStrength].valueString = "500mg"
* extension[intervention].extension[dosageLevels].valueString = "500mg twice daily"
* dosage[+].route = $IDMP_DUMMY#R1 "oral"
* extension[intervention].extension[regimen].valueString = "Twice daily for 12 weeks"
* extension[intervention].extension[use].valueCodeableConcept = $NCIT#C41161 "Experimental Intervention"
* extension[intervention].extension[imp-nimp].valueCodeableConcept = $NCIT#C202579 "MP"
* extension[intervention].extension[sourcing].valueCodeableConcept = $NCIT#C215659 "Centrally Sourced"


// TODO the following references a Medication but it should be a MedicationDefinition - FSH does not allow this even though it is in the spec
//* productReference = Reference(Medication-06)  // Nonproprietary Name // pharmaceuticalDoseForm

//--------------------------------------------------------------------------------------
//
Instance: InterventionTable-Row2
InstanceOf: m11-intervention-table
Usage: #example

Description: "Table defining the trial interventions"
* id = "InterventionTable-Row2" // This is specified ONLY to allow documentatation of examples - it is not normally specified

* status = #draft


* title = "Placebo Arm" // armName
* extension[intervention].extension[armType].valueCodeableConcept = $NCIT#C174268 "Placebo Comparator Arm" // armType
* productCodeableConcept = $SpID#EX2015/03  "Placebo" // Sponsor Investigational Product Code (and name)
* extension[intervention].extension[interventionType].valueCodeableConcept = $NCIT#C1909 "Drug"
//* productReference(intervention-medication)
* extension[intervention].extension[dosageStrength].valueString = "N/A"
* extension[intervention].extension[dosageLevels].valueString = "N/A"
* dosage[+].route = $IDMP_DUMMY#R1 "oral"
* extension[intervention].extension[regimen].valueString = "Twice daily for 12 weeks"
* extension[intervention].extension[use].valueCodeableConcept = $NCIT#C753 "Placebo"
* extension[intervention].extension[imp-nimp].valueCodeableConcept = $NCIT#C156473 "NIMP"
* extension[intervention].extension[sourcing].valueCodeableConcept = $NCIT#C215659 "Centrally Sourced"


// TODO the following references a Medication but it should be a MedicationDefinition - FSH does not allow this even though it is in the spec
//* productReference = Reference(Medication-06)  // Nonproprietary Name // pharmaceuticalDoseForm

//--------------------------------------------------------------------------------------
//
Instance: InterventionTable-Row3
InstanceOf: m11-intervention-table
Usage: #example

Description: "Table defining the trial interventions"
* id = "InterventionTable-Row3" // This is specified ONLY to allow documentatation of examples - it is not normally specified

* status = #draft


* title = "Open-label Extension Arm" // armName
* extension[intervention].extension[armType].valueCodeableConcept = $NCIT#C174266 "Experimental Arm" // armType
* productCodeableConcept = $SpID#EX2015/03  "Exoticillin" // Sponsor Investigational Product Code (and name)
* extension[intervention].extension[interventionType].valueCodeableConcept = $NCIT#C1909 "Drug"
//* productReference(intervention-medication)
* extension[intervention].extension[dosageStrength].valueString = "250mg or 500mg"
* extension[intervention].extension[dosageLevels].valueString = "Flexible dosing"
* dosage[+].route = $IDMP_DUMMY#R1 "oral"
* extension[intervention].extension[regimen].valueString = "Once or twice daily for 24 weeks"
* extension[intervention].extension[use].valueCodeableConcept = $NCIT#C41161 "Experimental Intervention"
* extension[intervention].extension[imp-nimp].valueCodeableConcept = $NCIT#C202579 "MP"
* extension[intervention].extension[sourcing].valueCodeableConcept = $NCIT#C215659 "Centrally Sourced"


// TODO the following references a Medication but it should be a MedicationDefinition - FSH does not allow this even though it is in the spec
//* productReference = Reference(Medication-06)  // Nonproprietary Name // pharmaceuticalDoseForm
