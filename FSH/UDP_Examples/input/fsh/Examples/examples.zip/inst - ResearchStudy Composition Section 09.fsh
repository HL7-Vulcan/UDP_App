Instance: ResearchStudy-Composition-M11Sections
InstanceOf: m11-research-study-profile
Title: "Research Study with Composition Section for M11 Sections"
Usage: #example
Description: """

    """ // TODO Check server details 
* id = "ResearchStudy-Composition-M11Sections"  // This is specified ONLY to allow documentatation of examples - it is not normally specified

* status = #active

* identifier[+].type.text = "Sponsor Identifier"
* identifier[=].system = $SpID
* identifier[=].value = "ABC-123"
 
* version = "(a)"

* title = "Illustration of Assembling Narrative Sections"

* extension[m11-research-study].extension[versionDate].valueDate = 2017-10-01
* extension[m11-research-study].extension[originalProtocol].valueCodeableConcept = $NCIT#C218485	"Protocol Not Amended"

* extension[NarrativeElements][+].valueReference = Reference(Narrative-Composition-M11Section07)
* extension[NarrativeElements][+].valueReference = Reference(Narrative-Composition-M11Section08)
* extension[NarrativeElements][+].valueReference = Reference(Narrative-Composition-M11Section09)
