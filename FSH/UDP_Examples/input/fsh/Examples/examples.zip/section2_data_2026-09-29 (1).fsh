Instance: Narrative-Composition-M11Section02
InstanceOf: m11-research-study-narratives
Title: "Example Narrative Single Composition with a Section for Each M11 Section"
Usage: #example
Description: """Example Narrative Single Composition with a contained section for e part of M11 Section 02.
"""

* status = #final
* type = $NCIT#C207508 // Narrative
* date = "2025-06-30T12:46:00Z"
* author = Reference(Narrative-Organization) // Reference to Organization: Marketing 
* title = "Example Narrative with Section per Section - (this is the Composition Title}"
* section[+]
  * title = "Section 2.1"
  * code = $NCIT#C218521  "ICH M11 Protocol Section 2.1 Purpose of Trial"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
              The primary purpose of this trial is to evaluate the efficacy and safety of exoticillin in the treatment of bronchitis in Japanese patients with iatrogenic diabetes mellitus.
        </div>
      """
* section[+]
  * title = "Section 2.2.1.1"
  /// TODO Check this isn't in NCIT
  * code = $UDP_Term#001  "ICH M11 Protocol Section 2.2.1.1 Risk Summary and Mitigation Strategy - Trial Intervention"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
              The main risk associated with the investigational intervention is the potential for hypersensitivity reactions, including anaphylaxis, which has been observed in prior studies at a rate of approximately 1 in 10,000 patients.
    </div>
    """
* section[+]
  * title = "Section 2.2.1.2"
  /// TODO Check this isn't in NCIT
  * code = $UDP_Term#002  "ICH M11 Protocol Section 2.2.1.2 Risk Summary and Mitigation Strategy - Trial Procedures"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
              Risks arising from trial procedures include discomfort and bruising from venepuncture, and a small risk of infection at injection sites during pharmacokinetic sampling visits.
    </div>
    """
* section[+]
  * title = "Section 2.2.1.3"
  /// TODO Check this isn't in NCIT
  * code = $UDP_Term#003  "ICH M11 Protocol Section 2.2.1.3 Risk Summary and Mitigation Strategy - Other"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
              There is a potential risk of disease progression in participants who do not respond to the investigational intervention. Rescue therapy protocols are in place to mitigate this risk.
    """

* section[+]
  * title = "Section 2.2.2"
  * code = $NCIT#C218524  "ICH M11 Protocol Section 2.2.2 Benefit Summary"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
              Exoticillin has demonstrated a clinically meaningful reduction in symptom duration in Phase II studies, with a mean reduction of 3.2 days compared to placebo. Benefits are anticipated to outweigh the identified risks in the target population.
    </div>
    """

* section[+]
  * title = "Section 2.2.3"
  * code = $NCIT#C218525  "ICH M11 Protocol Section 2.2.3 Overall Risk-Benefit Assessment"
  * text.status = #additional
  * text.div = """<div xmlns='http://www.w3.org/1999/xhtml' xml:lang="en" lang="en"> 
              Based on the available non-clinical and clinical data, the benefit-risk balance for exoticillin in the treatment of bronchitis in Japanese patients with iatrogenic diabetes mellitus is considered favourable. The identified risks are manageable through the protocol-specified monitoring and mitigation measures.
    </div>
    """