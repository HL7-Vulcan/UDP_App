namespace UDP_App.Services;

/// <summary>
/// Parses and substitutes {{TOKEN}} / {{REPEAT...}} / REPEAT{{ }} template tokens.
/// Matching is done by bracket-counting so nested {{ }} pairs are handled correctly.
/// </summary>
public static class TokenParser
{
    /// <summary>
    /// Find the index just after the closing '}}' that matches the '{{' at <paramref name="start"/>.
    /// Returns -1 if unmatched.
    /// </summary>
    public static int FindTokenEnd(string text, int start)
    {
        int depth = 0, i = start;
        while (i < text.Length - 1)
        {
            if (text[i] == '{' && text[i + 1] == '{')  { depth++; i += 2; }
            else if (text[i] == '}' && text[i + 1] == '}') { depth--; i += 2; if (depth == 0) return i; }
            else i++;
        }
        return -1;
    }

    /// <summary>
    /// Find the next '{{' at or after <paramref name="from"/>.
    /// Returns -1 if none found.
    /// </summary>
    public static int FindTokenStart(string text, int from = 0)
    {
        int i = text.IndexOf("{{", from, StringComparison.Ordinal);
        return i;
    }

    /// <summary>
    /// Replace all simple (non-REPEAT) tokens in <paramref name="template"/> using
    /// <paramref name="getValue"/>. Nested tokens are resolved inner-first.
    /// </summary>
    public static string Substitute(string template, Func<string, string?> getValue)
    {
        var sb = new System.Text.StringBuilder();
        int pos = 0;
        while (pos < template.Length)
        {
            int open = FindTokenStart(template, pos);
            if (open < 0) { sb.Append(template, pos, template.Length - pos); break; }

            int close = FindTokenEnd(template, open);
            if (close < 0) { sb.Append(template, pos, template.Length - pos); break; }

            // Append literal text before this token
            sb.Append(template, pos, open - pos);

            // Extract token content (between outer {{ and }})
            string content = template.Substring(open + 2, close - open - 4);

            // If content itself contains {{ }}, resolve inner tokens first
            string resolvedContent = content.Contains("{{")
                ? Substitute(content, getValue)
                : content;

            // Skip REPEAT tokens — those are handled by SubstituteRepeat
            if (resolvedContent.StartsWith("REPEAT", StringComparison.Ordinal))
            {
                sb.Append("{{").Append(resolvedContent).Append("}}");
            }
            else
            {
                var val = getValue(resolvedContent);
                sb.Append(val ?? string.Empty);
            }

            pos = close;
        }
        return sb.ToString();
    }

    /// <summary>
    /// Find the first {{REPEAT...}} block in <paramref name="template"/> and expand it
    /// once per entry in <paramref name="iterations"/>.  For each iteration, any nested
    /// inner {{REPEAT...}} blocks with _X tokens are expanded using that iteration's
    /// <c>iceIds</c>, then all remaining tokens are substituted using <c>fieldValues</c>.
    /// Returns (expandedText, matchStart, matchLength), or null if no REPEAT found.
    /// </summary>
    public static (string expanded, int matchStart, int matchLength)? ExpandOuterRepeat(
        string template,
        IEnumerable<(Func<string, string?> fieldValues, IEnumerable<string> iceIds)> iterations)
    {
        int i = 0;
        while (i < template.Length)
        {
            int open = FindTokenStart(template, i);
            if (open < 0) break;
            int close = FindTokenEnd(template, open);
            if (close < 0) break;

            string content = template.Substring(open + 2, close - open - 4);
            if (content.StartsWith("REPEAT", StringComparison.Ordinal))
            {
                int lineStart = open;
                while (lineStart > 0 && template[lineStart - 1] != '\n' && template[lineStart - 1] != '\r')
                    lineStart--;

                string rowPattern = content.Substring("REPEAT".Length);

                int blockEnd = close;
                while (blockEnd < template.Length && (template[blockEnd] == ' ' || template[blockEnd] == '\t'))
                    blockEnd++;
                if (blockEnd < template.Length && template[blockEnd] == '\r') blockEnd++;
                if (blockEnd < template.Length && template[blockEnd] == '\n') blockEnd++;

                var sb = new System.Text.StringBuilder();
                bool firstIter = true;
                foreach (var (fieldValues, iceIds) in iterations)
                {
                    if (!firstIter) sb.AppendLine();
                    firstIter = false;

                    // Expand any inner REPEAT blocks (those with _X tokens) using this iteration's iceIds
                    string body = rowPattern;
                    bool anyInner = true;
                    while (anyInner)
                    {
                        var inner = FindAndExpandRepeat(body, iceIds);
                        if (inner.HasValue)
                        {
                            var (exp, ms, ml) = inner.Value;
                            body = body.Remove(ms, ml).Insert(ms, exp);
                        }
                        else anyInner = false;
                    }

                    // Drop lines whose single token resolves to null/empty, then substitute
                    body = DropEmptyTokenLines(body, fieldValues);
                    body = Substitute(body, fieldValues);
                    sb.Append(body);
                }

                return (sb.ToString(), lineStart, blockEnd - lineStart);
            }

            i = close;
        }
        return null;
    }

    /// <summary>
    /// Find a {{REPEAT<content>}} token in <paramref name="template"/>,
    /// expand it by substituting {{TABLE_ROW_X}} with each row id,
    /// and return (expandedLines, matchStart, matchLength).
    /// Leading horizontal whitespace before {{REPEAT is included in the match and discarded.
    /// Returns null if no REPEAT token found.
    /// </summary>
    public static (string expanded, int matchStart, int matchLength)? FindAndExpandRepeat(
        string template, IEnumerable<string> rowIds)
    {
        int i = 0;
        while (i < template.Length)
        {
            int open = FindTokenStart(template, i);
            if (open < 0) break;

            int close = FindTokenEnd(template, open);
            if (close < 0) break;

            string content = template.Substring(open + 2, close - open - 4);
            if (content.StartsWith("REPEAT", StringComparison.Ordinal))
            {
                // Walk back to the start of the line so we remove the whole {{REPEAT...}} line,
                // but preserve any leading whitespace that is INSIDE the content (after REPEAT).
                int lineStart = open;
                while (lineStart > 0 && template[lineStart - 1] != '\n' && template[lineStart - 1] != '\r')
                    lineStart--;

                // Content after "REPEAT" is the per-row line pattern.
                // Any leading whitespace in rowPattern is part of the intended output — preserve it.
                string rowPattern = content.Substring("REPEAT".Length);

                // Consume the newline that follows the closing }} so we don't leave a blank line
                int blockEnd = close;
                while (blockEnd < template.Length && (template[blockEnd] == ' ' || template[blockEnd] == '\t'))
                    blockEnd++;
                if (blockEnd < template.Length && template[blockEnd] == '\r') blockEnd++;
                if (blockEnd < template.Length && template[blockEnd] == '\n') blockEnd++;

                // Discover the row-id token(s): any {{..._X}} token inside the row pattern.
                // All such tokens are substituted with the rowId for that iteration.
                var rowTokens = new System.Collections.Generic.HashSet<string>(
                    StringComparer.Ordinal);
                {
                    int scan = 0;
                    while (scan < rowPattern.Length)
                    {
                        int to = FindTokenStart(rowPattern, scan);
                        if (to < 0) break;
                        int tc = FindTokenEnd(rowPattern, to);
                        if (tc < 0) break;
                        string tok = rowPattern.Substring(to + 2, tc - to - 4);
                        if (tok.EndsWith("_X", StringComparison.Ordinal))
                            rowTokens.Add(tok);
                        scan = tc;
                    }
                }
                var sb = new System.Text.StringBuilder();
                if (rowTokens.Count == 0)
                {
                    // No _X row-id tokens in the pattern: this is a "emit once" REPEAT block
                    // (e.g. a single-value field like treatment).  Emit the pattern exactly once,
                    // leaving any {{field}} tokens intact for Substitute to resolve afterward.
                    sb.Append(rowPattern);
                }
                else
                {
                    bool first = true;
                    foreach (var rowId in rowIds)
                    {
                        if (!first) sb.AppendLine();
                        first = false;
                        // Substitute only the _X tokens; leave all other {{field}} tokens intact.
                        sb.Append(Substitute(rowPattern, key =>
                            rowTokens.Contains(key) ? rowId : "{{" + key + "}}"));
                    }
                }

                return (sb.ToString(), lineStart, blockEnd - lineStart);
            }

            i = close;
        }
        return null;
    }

    /// <summary>
    /// Expand a REPEAT{{ }} block for a single characteristic, selecting the correct
    /// format sub-block (RANGE{{ }}, TYPE{{ }}, BOOLEAN{{ }}, QUANTITY{{ }}) based on
    /// <paramref name="format"/> ("range", "type", "bool", "qty"), then substituting
    /// all remaining tokens using <paramref name="getValue"/>.
    /// </summary>
    public static string ExpandCharacteristic(string eligTpl, string format,
        Func<string, string?> getValue)
    {
        var fmtKey = format?.ToLowerInvariant() switch
        {
            "type" => "TYPE",
            "bool" => "BOOLEAN",
            "qty"  => "QUANTITY",
            _      => "RANGE",
        };

        var sb  = new System.Text.StringBuilder();
        int pos = 0;

        while (pos < eligTpl.Length)
        {
            int repeatIdx = eligTpl.IndexOf("REPEAT{{", pos, StringComparison.Ordinal);
            if (repeatIdx < 0) break;

            int outerOpen  = repeatIdx + "REPEAT".Length;
            int outerClose = FindTokenEnd(eligTpl, outerOpen);
            if (outerClose < 0) break;

            string outerContent = eligTpl.Substring(outerOpen + 2, outerClose - outerOpen - 4);

            foreach (var fmt in new[] { "RANGE", "TYPE", "BOOLEAN", "QUANTITY" })
            {
                if (!outerContent.StartsWith(fmt + "{{", StringComparison.Ordinal)) continue;
                if (fmt == fmtKey)
                {
                    int innerOpen  = fmt.Length;
                    int innerClose = FindTokenEnd(outerContent, innerOpen);
                    if (innerClose >= 0)
                    {
                        string charTpl = outerContent.Substring(innerOpen + 2,
                                                                 innerClose - innerOpen - 4);
                        var filtered = DropEmptyTokenLines(charTpl, getValue);
                        sb.Append(Substitute(filtered, getValue));
                        sb.AppendLine();
                    }
                }
                break;
            }

            pos = outerClose;
            while (pos < eligTpl.Length && (eligTpl[pos] == ' ' || eligTpl[pos] == '\t'))
                pos++;
            if (pos < eligTpl.Length && eligTpl[pos] == '\r') pos++;
            if (pos < eligTpl.Length && eligTpl[pos] == '\n') pos++;
        }

        return sb.ToString();
    }

    /// <summary>
    /// Drop a line from a multi-line block if it contains exactly one top-level token
    /// and that token's value (from <paramref name="getValue"/>) is empty or whitespace.
    /// Line endings are preserved exactly.
    /// </summary>
    public static string DropEmptyTokenLines(string block, Func<string, string?> getValue)
    {
        // Split preserving line endings by scanning character by character
        var lines = new List<(string content, string ending)>();
        int i = 0;
        while (i < block.Length)
        {
            int lineStart = i;
            while (i < block.Length && block[i] != '\r' && block[i] != '\n') i++;
            string content = block.Substring(lineStart, i - lineStart);
            string ending = "";
            if (i < block.Length)
            {
                if (block[i] == '\r' && i + 1 < block.Length && block[i + 1] == '\n') { ending = "\r\n"; i += 2; }
                else if (block[i] == '\r') { ending = "\r"; i++; }
                else { ending = "\n"; i++; }
            }
            lines.Add((content, ending));
        }

        var sb = new System.Text.StringBuilder();
        foreach (var (content, ending) in lines)
        {
            // Count top-level tokens on this line
            var tokens = new List<string>();
            int j = 0;
            while (j < content.Length)
            {
                int open = FindTokenStart(content, j);
                if (open < 0) break;
                int close = FindTokenEnd(content, open);
                if (close < 0) break;
                tokens.Add(content.Substring(open + 2, close - open - 4));
                j = close;
            }

            bool drop = tokens.Count == 1
                && string.IsNullOrWhiteSpace(getValue(tokens[0]));

            if (!drop) sb.Append(content).Append(ending);
        }
        return sb.ToString();
    }
}
